package nl.han.ica.SubKiller;

import nl.han.ica.OOPDProcessingEngineHAN.Objects.Sprite;

/**
 * Baseclass voor diverse WeaponFactories. Elk spelobject dat wapens af kan
 * vuren (AttackCapableGameObject) krijgt een WeaponFactory die het spelobject
 * kan gebruiken om een wapen af te vuren.
 */
public abstract class AbstractWeaponFactory implements IWeaponFactory {

	private IGameObjectUpdateInteraction gameObjectsUpdater;
	private Sprite sprite;

	private int frames;
	private int hitpoints;
	private int scoreWhenDestroyed;
	private float minBoundary;
	private float maxBoundary;
	private float direction;
	private float speed;
	private IUpdateGameDashboard dashboardUpdater;
	private int damageInflicted;

	protected AbstractWeaponFactory() {
	};

	/**
	 *
	 * @param x
	 * @param y
	 */
	public abstract void CreateWeapon(float x, float y);

	/**
	 *
	 * @return Sprite
	 */
	protected Sprite getSprite() {
		return sprite;
	}

	/**
	 *
	 * @return IGameObjectUpdateInteraction
	 */
	protected final IGameObjectUpdateInteraction getGameObjectUpdater() {
		return gameObjectsUpdater;
	}

	/**
	 *
	 * @param gameObjectsUpdater
	 */
	protected final void setGameObjectUpdater(IGameObjectUpdateInteraction gameObjectsUpdater) {
		this.gameObjectsUpdater = gameObjectsUpdater;
	}

	/**
	 *
	 * @return int
	 */
	protected final int getFrames() {
		return frames;
	}

	/**
	 *
	 * @param frames
	 */
	protected final void setFrames(int frames) {
		this.frames = frames;
	}

	/**
	 *
	 * @return int
	 */
	protected final int getHitpoints() {
		return hitpoints;
	}

	/**
	 *
	 * @param hitpoints
	 */
	protected final void setHitpoints(int hitpoints) {
		this.hitpoints = hitpoints;
	}

	/**
	 *
	 * @return float
	 */
	protected final int getScoreWhenDestroyed() {
		return scoreWhenDestroyed;
	}

	/**
	 *
	 * @param scoreWhenDestroyed
	 */
	protected final void setScoreWhenDestroyed(int scoreWhenDestroyed) {
		this.scoreWhenDestroyed = scoreWhenDestroyed;
	}

	/**
	 *
	 * @return float
	 */
	protected final float getMinBoundary() {
		return minBoundary;
	}

	/**
	 *
	 * @return float
	 */
	protected final float getMaxBoundary() {
		return maxBoundary;
	}

	/**
	 *
	 * @param minBoundary
	 */
	protected final void setMinBoundary(float minBoundary) {
		this.minBoundary = minBoundary;
	}

	/**
	 *
	 * @param maxBoundary
	 */
	protected final void setMaxBoundary(float maxBoundary) {
		this.maxBoundary = maxBoundary;
	}

	/**
	 *
	 * @return float
	 */
	protected final float getDirection() {
		return direction;
	}

	/**
	 *
	 * @param direction
	 */
	protected final void setDirection(float direction) {
		this.direction = direction;
	}

	/**
	 *
	 * @return float
	 */
	protected final float getSpeed() {
		return speed;
	}

	/**
	 *
	 * @param speed
	 */
	protected final void setSpeed(float speed) {
		this.speed = speed;
	}

	/**
	 *
	 * @return IUpdateGameDashboard
	 */
	protected final IUpdateGameDashboard getDashboardUpdater() {
		return dashboardUpdater;
	}

	/**
	 *
	 * @param dashboardUpdater
	 */
	protected final void setDashboardUpdater(IUpdateGameDashboard dashboardUpdater) {
		this.dashboardUpdater = dashboardUpdater;
	}

	/**
	 *
	 * @return IGameObjectUpdateInteraction
	 */
	protected final IGameObjectUpdateInteraction getGameObjectsUpdater() {
		return gameObjectsUpdater;
	}

	/**
	 *
	 * @param gameObjectsUpdater
	 */
	protected final void setGameObjectsUpdater(IGameObjectUpdateInteraction gameObjectsUpdater) {
		this.gameObjectsUpdater = gameObjectsUpdater;
	}

	/**
	 *
	 * @return int
	 */
	protected final int getDamageInflicted() {
		return damageInflicted;
	}

	/**
	 *
	 * @param damageInflicted
	 */
	protected final void setDamageInflicted(int damageInflicted) {
		this.damageInflicted = damageInflicted;
	}

	/**
	 *
	 * @param sprite
	 */
	protected final void setSprite(Sprite sprite) {
		this.sprite = sprite;
	}

}
