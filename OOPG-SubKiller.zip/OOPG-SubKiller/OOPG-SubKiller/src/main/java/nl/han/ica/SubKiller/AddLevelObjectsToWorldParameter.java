package nl.han.ica.SubKiller;

/**
 * Parameterobject voor AddLevelObjectsToWorld methode (class Level)
 */
public class AddLevelObjectsToWorldParameter {
	public IGameObjectUpdateInteraction gameObjectUpdater;
	public IGameWorldInfo worldInfo;
	public IUpdateGameDashboard dashBoardUpdater;

	/**
	 * Add all world interfaces at once
	 * 
	 * @param gameObjectUpdater
	 * @param worldInfo
	 * @param dashBoardUpdater
	 */
	public AddLevelObjectsToWorldParameter(IGameObjectUpdateInteraction gameObjectUpdater, IGameWorldInfo worldInfo,
			IUpdateGameDashboard dashBoardUpdater) {
		this.gameObjectUpdater = gameObjectUpdater;
		this.worldInfo = worldInfo;
		this.dashBoardUpdater = dashBoardUpdater;
	}
}