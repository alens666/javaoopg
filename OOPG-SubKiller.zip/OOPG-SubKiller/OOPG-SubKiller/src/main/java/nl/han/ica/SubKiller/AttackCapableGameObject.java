package nl.han.ica.SubKiller;

import nl.han.ica.OOPDProcessingEngineHAN.Objects.Sprite;

/**
 * Baseclass voor alle DestroyableGameObject classes die een wapen kunnen
 * afvuren. Bevat een IWeaponFactory verwijzing om wapens te kunnen afvuren.
 * Definieert vanaf welk punt op het object het wapen wordt afgevuurd.
 */
public class AttackCapableGameObject extends DestroyableGameObject {
	private IWeaponFactory weaponFactory;
	private float currentX, currentY;

	private float weaponStartX, weaponStartY;
	private long lastTimeFired;
	private long minimumTimeBetweenSucessiveAttacksInMilliseconds;

	/**
	 *
	 * @param sprite
	 * @param frames
	 * @param hitpoints
	 * @param scoreWhenDestroyed
	 * @param minBoundary
	 * @param maxBoundary
	 * @param currentX
	 * @param currentY
	 * @param direction
	 * @param speed
	 * @param dashboardUpdater
	 * @param gameObjectsUpdater
	 * @param isFriendly
	 * @param weaponFactory
	 * @param weaponStartX
	 * @param weaponStartY
	 */
	public AttackCapableGameObject(Sprite sprite, int frames, int hitpoints, int scoreWhenDestroyed, float minBoundary,
			float maxBoundary, float currentX, float currentY, float direction, float speed,
			IUpdateGameDashboard dashboardUpdater, IGameObjectUpdateInteraction gameObjectsUpdater, boolean isFriendly,
			IWeaponFactory weaponFactory, float weaponStartX, float weaponStartY,
			long minimumTimeBetweenSucessiveAttacksInMilliseconds) {
		super(sprite, frames, hitpoints, scoreWhenDestroyed, minBoundary, maxBoundary, currentX, currentY, direction,
				speed, dashboardUpdater, gameObjectsUpdater, isFriendly);
		this.weaponFactory = weaponFactory;
		this.weaponStartX = weaponStartX;
		this.weaponStartY = weaponStartY;
		this.minimumTimeBetweenSucessiveAttacksInMilliseconds = minimumTimeBetweenSucessiveAttacksInMilliseconds;
	}

	@Override
	public void update() {
		currentX = getX();
		currentY = getY();
	}

	/**
	 * fire a weapon
	 */
	protected void fireWeapon() {
		float[] positions = calculateStartPositonOfWeapon(weaponStartX, weaponStartY);
		weaponFactory.CreateWeapon(positions[0], positions[1]);
	}

	private float[] calculateStartPositonOfWeapon(float weaponStartX, float weaponStartY) {
		float positions[] = new float[2];

		positions[0] = currentX + weaponStartX;
		positions[1] = currentY + weaponStartY;

		return positions;
	}

	protected boolean attackCooldownPeriodInSecondsExpired() {
		boolean canFire = false;
		long currentTimeInMilliSecond = System.currentTimeMillis();

		if (lastTimeFired == 0) {
			lastTimeFired = currentTimeInMilliSecond;
			canFire = true;
		}

		long timePassed = currentTimeInMilliSecond - lastTimeFired;
		if (timePassed > minimumTimeBetweenSucessiveAttacksInMilliseconds) {
			lastTimeFired = currentTimeInMilliSecond;
			canFire = true;
		}

		return canFire;
	}
}
