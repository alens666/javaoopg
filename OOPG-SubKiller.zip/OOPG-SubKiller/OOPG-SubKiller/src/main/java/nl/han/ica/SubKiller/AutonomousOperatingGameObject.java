package nl.han.ica.SubKiller;

import nl.han.ica.OOPDProcessingEngineHAN.Objects.Sprite;

/**
 * Baseclass voor alle spelobjecten die zelfstandig opereren binnen de
 * spelwereld. Weet hoe zich te gedragen bij het bereiken van een grenspositie
 * op het speelveld en wanneer ze moeten aanvallen (wapen afvuren).
 */
public abstract class AutonomousOperatingGameObject extends AttackCapableGameObject {
	/**
	 *
	 * @param sprite
	 * @param frames
	 * @param hitpoints
	 * @param scoreWhenDestroyed
	 * @param minBoundary
	 * @param maxBoundary
	 * @param currentX
	 * @param currentY
	 * @param direction
	 * @param speed
	 * @param dashboardUpdater
	 * @param gameObjectsUpdater
	 * @param isFriendly
	 * @param weaponFactory
	 * @param weaponStartY
	 * @param weaponStartX
	 */
	public AutonomousOperatingGameObject(Sprite sprite, int frames, int hitpoints, int scoreWhenDestroyed,
			float minBoundary, float maxBoundary, float currentX, float currentY, float direction, float speed,
			IUpdateGameDashboard dashboardUpdater, IGameObjectUpdateInteraction gameObjectsUpdater, boolean isFriendly,
			IWeaponFactory weaponFactory, float weaponStartY, float weaponStartX,
			long minimumTimeBetweenSucessiveAttacksInMilliseconds) {
		super(sprite, frames, hitpoints, scoreWhenDestroyed, minBoundary, maxBoundary, currentX, currentY, direction,
				speed, dashboardUpdater, gameObjectsUpdater, isFriendly, weaponFactory, weaponStartX, weaponStartY,
				minimumTimeBetweenSucessiveAttacksInMilliseconds);
	}

	protected abstract void AutoAttack();

	@Override
	public void update() {
		super.update();
		if (getX() <= getMinBoundary()) {
			turn();
		} else if (getX() + getWidth() >= getMaxBoundary()) {
			turn();
		}

		AutoAttack();
	}

	private void turn() {
		float newDirection = getDirection() + 180;

		if (newDirection >= 360) {
			newDirection -= 360;
		}

		setDirection(newDirection);

		if (getTotalFrames() <= 1) {
			return;
		}

		if (getDirection() < 180) {
			setCurrentFrameIndex(0);
		} else {
			setCurrentFrameIndex(1);
		}
	}
}
