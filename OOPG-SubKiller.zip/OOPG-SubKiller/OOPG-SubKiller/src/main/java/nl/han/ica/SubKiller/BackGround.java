package nl.han.ica.SubKiller;

import nl.han.ica.OOPDProcessingEngineHAN.Objects.GameObject;
import processing.core.PGraphics;

/**
 * GameObject dat de achtergrond tekent. Bestaat uit lucht, zeebodem, en alles
 * ertussen is zeewater.
 */
public final class BackGround extends GameObject {
	private final int seaBottomColorR = 255;
	private final int seaBottomColorG = 153;
	private final int seaBottomColorB = 0;
	private final int seaWaterColorR = 51;
	private final int seaWaterColorG = 51;
	private final int seaWaterColorB = 255;
	private final int airColorR = 102;
	private final int airColorG = 204;
	private final int airColorB = 255;
	private IGameWorldInfo gameWorldInfo;

	/**
	 *
	 * @param gameWorldInfo
	 */
	public BackGround(IGameWorldInfo gameWorldInfo) {
		this.gameWorldInfo = gameWorldInfo;
	}

	@Override
	public void update() {
		// Do nothing, background is static.
		// This method has to be implemented due to abstract status in super
		// class.
	}

	@Override
	public void draw(PGraphics g) {
		g.rectMode(CORNER);

		drawAir(g);
		drawSeaWater(g);
		drawSeaBottom(g);
	}

	private void drawAir(PGraphics g) {
		g.fill(airColorR, airColorG, airColorB);
		g.rect(gameWorldInfo.getMinX(), gameWorldInfo.getMinY(), gameWorldInfo.getMaxX(),
				gameWorldInfo.getSeaSurfaceY());
	}

	private void drawSeaWater(PGraphics g) {
		g.fill(seaWaterColorR, seaWaterColorG, seaWaterColorB);
		g.rect(gameWorldInfo.getMinX(), gameWorldInfo.getSeaSurfaceY(), gameWorldInfo.getMaxX(),
				gameWorldInfo.getSeaBottomY());
	}

	private void drawSeaBottom(PGraphics g) {
		g.fill(seaBottomColorR, seaBottomColorG, seaBottomColorB);
		g.rect(gameWorldInfo.getMinX(), gameWorldInfo.getSeaBottomY(), gameWorldInfo.getMaxX(),
				gameWorldInfo.getMaxY());
	}
}
