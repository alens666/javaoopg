package nl.han.ica.SubKiller;

import nl.han.ica.OOPDProcessingEngineHAN.Objects.Sprite;

/**
 * Weaponfactories voor respectievelijk dieptebommen (gebruikt door het
 * marineschip), drijfbommen (gewone onderzeeër) en torpedo’s (super
 * onderzeeër).
 */
public class DepthChargeFactory extends AbstractWeaponFactory {
	private static DepthChargeFactory instance;

	/**
	 *
	 * @param gameObjectsUpdater
	 * @param gameWorldInfo
	 * @param dashboardUpdater
	 */
	private DepthChargeFactory(IGameObjectUpdateInteraction gameObjectsUpdater, IGameWorldInfo gameWorldInfo,
			IUpdateGameDashboard dashboardUpdater) {
		super();
		this.setMinBoundary(gameWorldInfo.getSeaSurfaceY());
		this.setMaxBoundary(gameWorldInfo.getSeaBottomY());
		this.setDamageInflicted(SubKillerSettings.DepthChargeDamage);
		this.setDashboardUpdater(dashboardUpdater);
		this.setDirection(Directions.DOWN);
		this.setFrames(1);
		this.setGameObjectUpdater(gameObjectsUpdater);
		this.setGameObjectsUpdater(gameObjectsUpdater);
		this.setHitpoints(SubKillerSettings.DepthChargeHitpoints);
		this.setScoreWhenDestroyed(SubKillerSettings.DepthChargeScore);
		this.setSpeed(SubKillerSettings.DepthChargeSpeed);
		this.setSprite(new Sprite("src/main/java/nl/han/ica/SubKiller/media/depthcharge.png"));
	}

	@Override
	public void CreateWeapon(float x, float y) {
		Weapon weapon = new Weapon(getSprite(), getFrames(), getHitpoints(), getScoreWhenDestroyed(), getMinBoundary(),
				getMaxBoundary(), x, y, getDirection(), getSpeed(), getDashboardUpdater(), getGameObjectsUpdater(),
				getDamageInflicted(), SubKillerSettings.FriendlyObject);
		getGameObjectUpdater().addGameObjectToWorld(weapon);
	}

	/**
	 *
	 * @param gameObjectUpdater
	 * @param gameWorldInfo
	 * @param dashboardUpdater
	 */
	public static void CreateFactory(IGameObjectUpdateInteraction gameObjectUpdater, IGameWorldInfo gameWorldInfo,
			IUpdateGameDashboard dashboardUpdater) {
		instance = new DepthChargeFactory(gameObjectUpdater, gameWorldInfo, dashboardUpdater);
	}

	public static DepthChargeFactory getFactoryInstance() {
		return instance;
	}
}