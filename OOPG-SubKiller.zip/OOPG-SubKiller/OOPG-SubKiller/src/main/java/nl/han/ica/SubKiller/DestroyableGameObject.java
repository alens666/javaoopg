package nl.han.ica.SubKiller;

import nl.han.ica.OOPDProcessingEngineHAN.Collision.ICollidableWithGameObjects;
import nl.han.ica.OOPDProcessingEngineHAN.Objects.AnimatedSpriteObject;
import nl.han.ica.OOPDProcessingEngineHAN.Objects.GameObject;
import nl.han.ica.OOPDProcessingEngineHAN.Objects.Sprite;
import nl.han.ica.OOPDProcessingEngineHAN.Sound.Sound;

import java.util.List;

/**
 * Baseclass voor alle spelobjecten die vernietigd kunnen worden. Houdt zelf een
 * administratie bij van schade en handelt vernietiging van zichzelf af
 * (bijwerken score). Houdt ook zelf bij binnen welke grenzen hij mag bewegen.
 */
public class DestroyableGameObject extends AnimatedSpriteObject implements ICollidableWithGameObjects {
	private int currentHitpoints;
	private int initialHitpoints;
	private int scoreWhenDestroyed;
	private float minBoundary;
	private float maxBoundary;
	private IUpdateGameDashboard dashboardUpdater;
	private IGameObjectUpdateInteraction gameObjectsUpdater;
	private Sound destroySound;
	private AnimatedSpriteObject explosion;
	private boolean isFriendly;

	/**
	 *
	 * @param sprite
	 * @param frames
	 * @param hitpoints
	 * @param scoreWhenDestroyed
	 * @param minBoundary
	 * @param maxBoundary
	 * @param startX
	 * @param startY
	 * @param direction
	 * @param speed
	 * @param dashboardUpdater
	 * @param gameObjectsUpdater
	 * @param isFriendly
	 */
	public DestroyableGameObject(Sprite sprite, int frames, int hitpoints, int scoreWhenDestroyed, float minBoundary,
			float maxBoundary, float startX, float startY, float direction, float speed,
			IUpdateGameDashboard dashboardUpdater, IGameObjectUpdateInteraction gameObjectsUpdater,
			boolean isFriendly) {
		super(sprite, frames);

		this.currentHitpoints = hitpoints;
		this.initialHitpoints = hitpoints;
		this.scoreWhenDestroyed = scoreWhenDestroyed;
		this.minBoundary = minBoundary;
		this.maxBoundary = maxBoundary;
		this.x = startX;
		this.y = startY;
		this.setDirection(direction);
		this.setSpeed(speed);
		this.dashboardUpdater = dashboardUpdater;
		this.gameObjectsUpdater = gameObjectsUpdater;
		this.isFriendly = isFriendly;
	}

	public void resetHitPoints() {
		currentHitpoints = initialHitpoints;
	}

	@Override
	public void update() {
	}

	/**
	 * Destroy and remove the DestroyableGameObject from the world
	 */
	protected void destroy() {
		if (!this.isFriendly()) {
			createExplosion();
			dashboardUpdater.updateScore(this.scoreWhenDestroyed);
		}

		gameObjectsUpdater.removeGameObjectFromWorld(this);
	}

	private void createExplosion() {
		explosion = new Explosion(getX(), getY(), getWidth(), getHeight(), getGameObjectsUpdater());
		gameObjectsUpdater.addGameObjectToWorld(explosion);
	}

	@Override
	public void setDirection(float inputDirection) {
		validateDirectionValue(inputDirection);
		super.setDirection(inputDirection);
	}

	private void validateDirectionValue(float inputDirection) {
		if (inputDirection != Directions.UP && inputDirection != Directions.RIGHT && inputDirection != Directions.DOWN
				&& inputDirection != Directions.LEFT)
			throw new IllegalArgumentException("Direction can only be 0, 90, 180, 270");
	}

	@Override
	public void gameObjectCollisionOccurred(List<GameObject> collidedGameObjects) {

		// Process colliding gameobjects.

		for (GameObject gameObject : collidedGameObjects) {

			// Only if colliding with a weapon damage will occur.
			if (!(gameObject instanceof Weapon))
				return;

			Weapon weapon = (Weapon) gameObject;

			// Enemy weapons will only damage friendly objects and vice verse
			if (this.isFriendly() == weapon.isFriendly()) {
				continue;
			}

			// Weapons do not explode when player gets hit (without dying)
			if (this instanceof Player) {
				getGameObjectsUpdater().removeGameObjectFromWorld(gameObject);
			} else {
				weapon.destroy();
			}

			this.currentHitpoints -= weapon.getDamageInflicted();
			if (this.currentHitpoints < 0)
				this.currentHitpoints = 0;
			if (this.currentHitpoints <= 0) {
				destroy();
			}
		}
	}

	/**
	 *
	 * @return int
	 */
	protected int getHitpoints() {
		return currentHitpoints;
	}

	/**
	 *
	 * @return float
	 */
	public float getMinBoundary() {
		return minBoundary;
	}

	/**
	 *
	 * @return float
	 */
	public float getMaxBoundary() {
		return maxBoundary;
	}

	/**
	 *
	 * @return IUpdateGameDashboard
	 */
	protected final IUpdateGameDashboard getDashboardUpdater() {
		return dashboardUpdater;
	}

	/**
	 *
	 * @return IGameObjectUpdateInteraction
	 */
	protected final IGameObjectUpdateInteraction getGameObjectsUpdater() {
		return gameObjectsUpdater;
	}

	/**
	 * @return Sound
	 */
	protected final Sound getDestroySound() {
		return destroySound;
	}

	/**
	 *
	 * @return boolean
	 */
	public boolean isFriendly() {
		return isFriendly;
	}

}
