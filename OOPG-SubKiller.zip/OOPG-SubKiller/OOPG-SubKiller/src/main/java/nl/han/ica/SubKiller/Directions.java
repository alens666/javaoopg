package nl.han.ica.SubKiller;

/**
 * Pseudo static class waarin mapping plaatsvind van zinvolle richtingsnamen
 * (up, right, down, left) naar een aantal graden (resp. 0, 90, 180, 270).
 */
public final class Directions {
	public static final float UP = 0;
	public static final float RIGHT = 90;
	public static final float DOWN = 180;
	public static final float LEFT = 270;

	private Directions() {
	};
}
