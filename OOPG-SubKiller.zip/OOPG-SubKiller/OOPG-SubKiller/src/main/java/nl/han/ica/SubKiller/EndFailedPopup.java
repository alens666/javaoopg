package nl.han.ica.SubKiller;

/**
 * Popups die getoond worden bij respectievelijk start, einde spel door verlies
 * en einde spel door winst.
 */
public class EndFailedPopup extends Popup {
	private static String imageFileName = SubKillerSettings.EndFailedPopupImageFileName;
	private static GameState gameStateAfterClose = GameState.START;

	/**
	 *
	 * @param messageText
	 * @param gameStateUpdater
	 * @param gameObjectUpdater
	 */
	public EndFailedPopup(String messageText, IGameStateInteraction gameStateUpdater,
			IGameObjectUpdateInteraction gameObjectUpdater) {

		super(imageFileName, messageText, gameStateAfterClose, gameStateUpdater, gameObjectUpdater);
	}
}
