package nl.han.ica.SubKiller;

/**
 * Popups die getoond worden bij respectievelijk start, einde spel door verlies
 * en einde spel door winst.
 */
public class EndSuccessPopup extends Popup {
	private static String imageFileName = SubKillerSettings.EndSuccessPopupImageFileName;
	private static GameState gameStateAfterClose = GameState.START;

	/**
	 *
	 * @param messageText
	 * @param gameStateUpdater
	 * @param gameObjectUpdater
	 */
	public EndSuccessPopup(String messageText, IGameStateInteraction gameStateUpdater,
			IGameObjectUpdateInteraction gameObjectUpdater) {
		super(imageFileName, messageText, gameStateAfterClose, gameStateUpdater, gameObjectUpdater);
	}
}
