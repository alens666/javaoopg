package nl.han.ica.SubKiller;

import nl.han.ica.OOPDProcessingEngineHAN.Objects.AnimatedSpriteObject;
import nl.han.ica.OOPDProcessingEngineHAN.Objects.Sprite;

import java.util.Timer;
import java.util.TimerTask;

/**
 * Toont een animatie van een explosie. Verdwijnt (verwijdert zichzelf) nadat de
 * animatie is uitgevoerd.
 */
public class Explosion extends AnimatedSpriteObject {
	private Timer timer = new Timer();
	private IGameObjectUpdateInteraction iGameObjectUpdateInteraction;

	/**
	 *
	 * @param x
	 * @param y
	 * @param width
	 * @param heigth
	 * @param iGameObjectUpdateInteraction
	 */
	public Explosion(float x, float y, float width, float heigth,
			IGameObjectUpdateInteraction iGameObjectUpdateInteraction) {
		super(new Sprite("src/main/java/nl/han/ica/SubKiller/media/explosie.png"), 8);
		setCurrentFrameIndex(0);
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = heigth;
		this.iGameObjectUpdateInteraction = iGameObjectUpdateInteraction;
		animateExplosion();
	}

	private void animateExplosion() {
		int amountOfMilisecondsForNextFrame = 60;

		timer.schedule(new TimerTask() {
			@Override
			public void run() {
				nextFrame();
			}
		}, 0, amountOfMilisecondsForNextFrame);
	}

	@Override
	public void update() {
		if (getCurrentFrameIndex() == getTotalFrames() - 1) {
			iGameObjectUpdateInteraction.removeGameObjectFromWorld(this);
		}
	}
}
