package nl.han.ica.SubKiller;

public enum GameState {
	PRESTART, WAIT, START, INPROGRESS
}
