/**
 * 
 */
package nl.han.ica.SubKiller;

import nl.han.ica.OOPDProcessingEngineHAN.Objects.GameObject;

/**
 * Interface om spelobjecten zichzelf of andere gameobjecten te verwijderen of
 * toe te voegen.
 */
public interface IGameObjectUpdateInteraction {
	/**
	 * Add GameObject to the SubKiller world
	 * 
	 * @param gameObject
	 */
	void addGameObjectToWorld(GameObject gameObject);

	/**
	 * Remove an GameObject from the SubKiller world
	 * 
	 * @param gameObject
	 */
	void removeGameObjectFromWorld(GameObject gameObject);

}
