package nl.han.ica.SubKiller;

/**
 * Interface om spelobjecten zichzelf of andere gameobjecten te verwijderen of
 * toe te voegen.
 */
public interface IGameStateInteraction {
	/**
	 *
	 * @param gameState
	 */
	void setGameState(GameState gameState);
}
