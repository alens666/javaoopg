package nl.han.ica.SubKiller;

/**
 * Interface om spelobjecten toegang te geven tot informatie uit de spelwereld.
 */
public interface IGameWorldInfo {
	float getSeaSurfaceY();

	float getSeaBottomY();

	float getMinX();

	float getMaxX();

	float getMinY();

	float getMaxY();

	float getPlayerX();

	float getPlayerY();
}
