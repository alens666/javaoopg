/**
 * 
 */
package nl.han.ica.SubKiller;

/**
 * Interface om spelobjecten wijzigingen t.b.v. Dashboard door te laten geven
 * aan de spelwereld.
 */
public interface IUpdateGameDashboard {
	/**
	 * update the score
	 * 
	 * @param scoreChange
	 */
	void updateScore(int scoreChange);

	/**
	 * update the hitpoints of the player
	 * 
	 * @param hitpoints
	 */
	void updatePlayerHitpointsLeft(int hitpoints);
}
