package nl.han.ica.SubKiller;

/**
 * Definieert interface voor een WeaponFactory. Wordt gebruikt om een
 * willekeurig AttackcapableGameObject wapens te laten afvuren.
 */
public interface IWeaponFactory {
	/**
	 * Create a weapon
	 * 
	 * @param x
	 * @param y
	 */
	public void CreateWeapon(float x, float y);
}
