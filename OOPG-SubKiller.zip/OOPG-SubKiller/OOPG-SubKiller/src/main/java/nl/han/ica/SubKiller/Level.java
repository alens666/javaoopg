package nl.han.ica.SubKiller;

import java.util.List;

import com.sun.scenario.Settings;

import nl.han.ica.OOPDProcessingEngineHAN.Objects.GameObject;

/**
 * Bevat de informatie van ��n level. Bouwt de spelsituatie op uit zeemijnen,
 * onderzee�rs en superonderzee�rs conform de specificatie die wordt gegeven
 * door LevelInfo.
 */
public class Level {
	private int levelNumber;
	private List<String> levelLines;

	/**
	 *
	 * @param levelNumber
	 * @param levelLines
	 */
	public Level(int levelNumber, List<String> levelLines) {
		this.levelNumber = levelNumber;
		this.levelLines = levelLines;
	}

	/**
	 * get the level number
	 * 
	 * @return
	 */
	public int getLevelNumber() {
		return levelNumber;
	}

	/**
	 * Interprets level text lines and adds specified objects to the gameworld
	 * 
	 * @param parameterObject
	 */
	public void AddLevelObjectsToWorld(AddLevelObjectsToWorldParameter parameterObject) {
		for (String line : levelLines) {
			String[] lineParts = line.split(SubKillerSettings.LevelInfoPartsSeparator);

			Utils.TrimStringArrayLines(lineParts);

			String requestedGameObjectType = lineParts[1].toLowerCase();

			GameObject gameObject;

			switch (requestedGameObjectType) {
			case "submarine":
				gameObject = createSubMarine(lineParts, parameterObject);
				break;
			case "supersubmarine":
				gameObject = createSuperSubMarine(lineParts, parameterObject);
				break;
			case "seamine":
				gameObject = createSeaMine(lineParts, parameterObject);
				break;
			default:
				gameObject = null;
			}

			if (gameObject != null)
				parameterObject.gameObjectUpdater.addGameObjectToWorld(gameObject);
		}
	}

	/**
	 * Create a GameObject instance of SeaMine
	 * 
	 * @param lineParts
	 * @param parameterObject
	 * @return
	 */
	private GameObject createSeaMine(String[] lineParts, AddLevelObjectsToWorldParameter parameterObject) {
		{
			int x = Integer.parseInt(lineParts[2]);
			SeaMine seaMine = new SeaMine(parameterObject.worldInfo.getSeaBottomY(),
					parameterObject.worldInfo.getSeaSurfaceY(), x, parameterObject.worldInfo.getSeaBottomY(),
					Directions.UP, parameterObject.dashBoardUpdater, parameterObject.gameObjectUpdater);

			return seaMine;
		}
	}

	/**
	 * Create a GameObject instance of SuperSubMarine
	 * 
	 * @param lineParts
	 * @param parameterObject
	 * @return
	 */
	private GameObject createSuperSubMarine(String[] lineParts, AddLevelObjectsToWorldParameter parameterObject) {
		int x = Integer.parseInt(lineParts[2]);
		int y = Integer.parseInt(lineParts[3]);
		int direction = Integer.parseInt(lineParts[4]);

		if (TorpedoFactory.getFactoryInstance() == null)
			TorpedoFactory.CreateFactory(parameterObject.gameObjectUpdater, parameterObject.worldInfo,
					parameterObject.dashBoardUpdater);
		AbstractWeaponFactory torpedofactory = TorpedoFactory.getFactoryInstance();

		AutonomousOperatingGameObject superSubMarine = new SuperSubMarine(parameterObject.worldInfo.getMinX(),
				parameterObject.worldInfo.getMaxX(), x, y, direction, parameterObject.dashBoardUpdater,
				parameterObject.gameObjectUpdater, torpedofactory, parameterObject.worldInfo);

		return superSubMarine;
	}

	/**
	 * Create a GameObject instance of SubMarine
	 * 
	 * @param lineParts
	 * @param parameterObject
	 * @return
	 */
	private GameObject createSubMarine(String[] lineParts, AddLevelObjectsToWorldParameter parameterObject) {
		int x = Integer.parseInt(lineParts[2]);
		int y = Integer.parseInt(lineParts[3]);
		int direction = Integer.parseInt(lineParts[4]);

		if (FloatBombFactory.getFactoryInstance() == null)
			FloatBombFactory.CreateFactory(parameterObject.gameObjectUpdater, parameterObject.worldInfo,
					parameterObject.dashBoardUpdater);
		AbstractWeaponFactory floatBombFactory = FloatBombFactory.getFactoryInstance();

		SubMarine subMarine = new SubMarine(parameterObject.worldInfo.getMinX(), parameterObject.worldInfo.getMaxX(), x,
				y, direction, parameterObject.dashBoardUpdater, parameterObject.gameObjectUpdater, floatBombFactory);

		return subMarine;
	}

}
