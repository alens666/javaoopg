package nl.han.ica.SubKiller;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

import nl.han.ica.OOPDProcessingEngineHAN.Persistence.FilePersistence;

/**
 * Leest alle levelinformatie uit een tekstbestand. Bevat 1 of meer Levels.
 */
public class LevelInfo {
	private ArrayList<Level> levels = new ArrayList<Level>();

	/**
	 *
	 * @param fileName
	 * @throws FileNotFoundException
	 */
	public void LoadFromFile(String fileName) throws FileNotFoundException {
		String[] lines = readLevelInformationFromFile();
		processTextLinesToLevels(lines);
	}

	private void processTextLinesToLevels(String[] lines) {
		int currentLevel = 0;
		List<String> levelLines = null;
		for (String line : lines) {
			if (line.length() == 0 || line.substring(0, 1).equals(SubKillerSettings.LevelInfoCommentLineIndicator))
				continue;

			String[] lineParts = line.split(SubKillerSettings.LevelInfoPartsSeparator);

			int i = Integer.parseInt(lineParts[0]);

			// if new level number is encountered, build a new Level object
			if (i > currentLevel) {
				currentLevel++;
				levelLines = new ArrayList<String>();
				levels.add(new Level(currentLevel, levelLines));
			}
			levelLines.add(line);
		}
	}

	private String[] readLevelInformationFromFile() throws FileNotFoundException {
		FilePersistence file = new FilePersistence(SubKillerSettings.LevelInfoFileName);
		if (!file.fileExists())
			throw new FileNotFoundException(
					String.format("Levelinformatie niet gevonden (%s)", SubKillerSettings.LevelInfoFileName));

		String[] lines = file.loadDataStringArray(SubKillerSettings.LevelInfoLineSeparator);
		return lines;
	}

	/**
	 * Get a level object for the specified level number
	 * 
	 * @param levelNumber
	 * @return
	 * @throws Exception
	 */
	public Level GetLevel(int levelNumber) throws Exception {
		for (Level l : levels) {
			if (l.getLevelNumber() == levelNumber)
				return l;
		}
		throw new Exception(String.format("Level %d not found", levelNumber));
	}

	/**
	 * Returns the number of levels.
	 * 
	 * @return
	 */
	public int getLevelCount() {
		return levels.size();
	}
}
