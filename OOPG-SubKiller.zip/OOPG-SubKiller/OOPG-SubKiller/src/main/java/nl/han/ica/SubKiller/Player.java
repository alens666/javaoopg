package nl.han.ica.SubKiller;

import nl.han.ica.OOPDProcessingEngineHAN.Objects.Sprite;

/**
 * Spelobject Marineschip. Wordt bestuurd door de speler. Reageert op
 * toetsaanslagen (pijltje link/rechts = bewegen, spatiebalk = wapen afvuren).
 */
public class Player extends AttackCapableGameObject {
	private final int LEFT = 37;
	private final int RIGHT = 39;
	private final int SPACEBAR = 32;
	private int speed;
	private long prevFireTime;
	private boolean fire = false;
	private final int pixelsUnderWater = 9;

	/**
	 *
	 * @param minBoundary
	 * @param maxBoundary
	 * @param currentX
	 * @param currentY
	 * @param direction
	 * @param dashboardUpdater
	 * @param gameObjectsUpdater
	 * @param weaponFactory
	 */
	public Player(float minBoundary, float maxBoundary, float currentX, float currentY, float direction,
			IUpdateGameDashboard dashboardUpdater, IGameObjectUpdateInteraction gameObjectsUpdater,
			IWeaponFactory weaponFactory) {
		super(new Sprite("src/main/java/nl/han/ica/SubKiller/media/marineBoat.png"), 1,
				SubKillerSettings.PlayerHitpoints, 0, minBoundary, maxBoundary, currentX, currentY, direction, 0,
				dashboardUpdater, gameObjectsUpdater, SubKillerSettings.FriendlyObject, weaponFactory,
				SubKillerSettings.PlayerWeaponXStart, SubKillerSettings.PlayerWeaponYStart,
				SubKillerSettings.TimeBetweenPlayerAttackMiliSeconds);
		setY(getY() - this.getHeight() + pixelsUnderWater);
	}

	@Override
	public void keyPressed(int keyCode, char key) {

		switch (keyCode) {
		case SPACEBAR:
			if (attackCooldownPeriodInSecondsExpired()) {
				fireWeapon();
				fire = false;
			}
			break;
		case LEFT:
			setDirection(270);
			setSpeed(SubKillerSettings.PlayerSpeed);
			break;
		case RIGHT:
			setDirection(90);
			setSpeed(SubKillerSettings.PlayerSpeed);
			break;

		default:
			break; // do nothing
		}
	}

	@Override
	public void keyReleased(int keyCode, char key) {
		speed = 0;
		if (keyCode == LEFT) {
			setSpeed(speed);
		}
		if (keyCode == RIGHT) {
			setSpeed(speed);
		}
	}

	@Override
	public void update() {
		super.update();
		if (getX() <= getMinBoundary()) {
			setX(0);
		} else if (getX() + getWidth() >= getMaxBoundary()) {
			setX(getMaxBoundary() - getWidth());
		}

		getDashboardUpdater().updatePlayerHitpointsLeft(getHitpoints());
	}

	@Override
	public void destroy() {
	}
}
