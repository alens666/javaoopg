package nl.han.ica.SubKiller;

import nl.han.ica.OOPDProcessingEngineHAN.Objects.Sprite;
import nl.han.ica.OOPDProcessingEngineHAN.Objects.SpriteObject;

/**
 * Base class voor tonen van een popup. Bevat plaatje en tekst. Zet na drukken
 * op een willekeurige toets een gegeven â€œspelstatusâ€� zodat de
 * SubKillerWorld weet wat deze verder moet doen.
 */
public class Popup extends SpriteObject {

	private Text messageText;
	private GameState gameStateAfterClose;
	private IGameStateInteraction gameStateUpdater;
	private IGameObjectUpdateInteraction gameObjectUpdater;

	/**
	 *
	 * @param imageFileName
	 * @param message
	 * @param gameStateAfterClose
	 * @param gameStateUpdater
	 * @param gameObjectUpdater
	 */
	public Popup(String imageFileName, String message, GameState gameStateAfterClose,
			IGameStateInteraction gameStateUpdater, IGameObjectUpdateInteraction gameObjectUpdater) {
		super(new Sprite(imageFileName));
		this.gameStateAfterClose = gameStateAfterClose;
		this.messageText = new Text(message);
		setMessageTextPosition();
		this.messageText.setZ(250);
		this.gameObjectUpdater = gameObjectUpdater;
		gameObjectUpdater.addGameObjectToWorld(messageText);
		this.gameStateUpdater = gameStateUpdater;
		this.setZ(200);
	}

	private void setMessageTextPosition() {
		messageText.setX(getX() + 20);
		messageText.setY(getY() + this.height - 50);
	}

	@Override
	public void setX(float x) {
		super.setX(x);

		// Text needs to move along with the picture
		setMessageTextPosition();
	}

	@Override
	public void setY(float y) {
		super.setY(y);

		// Text needs to move along with the picture
		setMessageTextPosition();
	}

	@Override
	public void keyPressed(int keyCode, char key) {
		gameObjectUpdater.removeGameObjectFromWorld(messageText);
		gameObjectUpdater.removeGameObjectFromWorld(this);
		gameStateUpdater.setGameState(gameStateAfterClose);
	}

	public void setTextSize(int textSize) {
		messageText.setTextSize(textSize);
	}

	@Override
	public void update() {
	}

}