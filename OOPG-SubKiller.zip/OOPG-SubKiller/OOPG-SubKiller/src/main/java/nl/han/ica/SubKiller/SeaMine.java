package nl.han.ica.SubKiller;

import nl.han.ica.OOPDProcessingEngineHAN.Objects.Sprite;

/**
 * Spelobject Zeemijn. Statisch geplaatst, bevindt zich op de zeebodem. Kan
 * loslaten van de zeebodem als de speler erboven vaart. en omhoog drijven. (Nog
 * niet geïmplementeerd).
 *
 */
public class SeaMine extends DestroyableGameObject {

	/**
	 *
	 * @param minBoundary
	 * @param maxBoundary
	 * @param startX
	 * @param startY
	 * @param direction
	 * @param dashboardUpdater
	 * @param gameObjectsUpdater
	 */
	public SeaMine(float minBoundary, float maxBoundary, float startX, float startY, float direction,
			IUpdateGameDashboard dashboardUpdater, IGameObjectUpdateInteraction gameObjectsUpdater) {
		super(new Sprite("nl/han/ica/SubKiller/media/SeaMineSmall.png"), 1, SubKillerSettings.SeaMineHitpoints,
				SubKillerSettings.SeaMineScore, minBoundary, maxBoundary, startX, startY, direction,
				SubKillerSettings.SeaMineSpeed, dashboardUpdater, gameObjectsUpdater, SubKillerSettings.EnemyObject);

		setY(getY() - this.height);
	}

	@Override
	public void update() {

	}
}
