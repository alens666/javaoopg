package nl.han.ica.SubKiller;

/**
 * Popups die getoond worden bij respectievelijk start, einde spel door verlies
 * en einde spel door winst.
 */
public class StartPopup extends Popup {
	private static String imageFileName = SubKillerSettings.StartPopupImageFileName;
	private static String messageText = "Press any key to start...";
	private static GameState gameStateAfterClose = GameState.START;

	/**
	 *
	 * @param gameStateUpdater
	 * @param gameObjectUpdater
	 */
	public StartPopup(IGameStateInteraction gameStateUpdater, IGameObjectUpdateInteraction gameObjectUpdater) {
		super(imageFileName, messageText, gameStateAfterClose, gameStateUpdater, gameObjectUpdater);
	}
}
