package nl.han.ica.SubKiller;

/**
 * Pseudo static class waar allerlei constanten voor spelbesturing worden
 * bijgehouden.
 */
public final class SubKillerSettings {
	public static final int TorpedoHitpoints = 1;
	public static final int TorpedoDamage = 2;
	public static final int TorpedoScore = 5;
	public static final float TorpedoSpeed = 3;
	public static final int FloatBombHitpoints = 1;
	public static final int FloatBombScore = 2;
	public static final float FloatBombSpeed = 1;
	public static final int FloatBombDamage = 1;
	public static final int DepthChargeDamage = 1;
	public static final int DepthChargeHitpoints = 1;
	public static final int DepthChargeScore = 0;
	public static final float DepthChargeSpeed = 2;
	public static final float AirHeight = 150;
	public static final float SeaBottomHeight = 100;
	public static final int WorldWidth = 1100;
	public static final int WorldHeight = 900;
	public static final String LevelInfoFileName = "main/java/nl/han/ica/subkiller/levels/levels.txt";
	public static final String LevelInfoLineSeparator = "\r\n";
	public static final String LevelInfoPartsSeparator = ",";
	public static final int SubMarineHitpoints = 1;
	public static final int SubMarineScore = 5;
	public static final int SubMarineAttackIntervalMilliSeconds = 5000;
	public static final int SubMarineSpeed = 3;
	public static final int SuperSubMarineHitpoints = 2;
	public static final int SuperSubMarineScore = 10;
	public static final int SuperSubMarineCoolDownMiliSeconds = 3000;
	public static final int SuperSubMarineSpeed = 4;
	public static final String StartPopupImageFileName = "src/main/java/nl/han/ica/SubKiller/media/subkillerstartscreen.jpg";
	public static final String EndSuccessPopupImageFileName = "src/main/java/nl/han/ica/subkiller/media/subkillerendscreen.jpg";
	public static final String EndFailedPopupImageFileName = "src/main/java/nl/han/ica/subkiller/media/subkillerdeathscreen.jpg";
	public static final float SubmarineWeaponYStartPoint = -40;
	public static final float SubmarineWeaponXStartPoint = 20;
	public static final float SuperSubmarineWeaponYStartPoint = -60;
	public static final float SuperSubmarineWeaponXStartPoint = 20;
	public static final float PlayerWeaponXStart = 50;
	public static final float PlayerWeaponYStart = 100;
	public static final int PlayerHitpoints = 5;
	public static final int PlayerSpeed = 3;
	public static final int TimeBetweenPlayerAttackMiliSeconds = 1000;
	public static final boolean FriendlyObject = true;
	public static final boolean EnemyObject = false;
	public static final int SeaMineHitpoints = 1;
	public static final int SeaMineScore = 1;
	public static final int SeaMineSpeed = 0;
	public static final String LevelInfoCommentLineIndicator = "#";
	public static final float SuperSubMarineDistanceToAttack = 100;
	public static final int DefaultPopupTextSize = 40;

	private SubKillerSettings() {
	};
}
