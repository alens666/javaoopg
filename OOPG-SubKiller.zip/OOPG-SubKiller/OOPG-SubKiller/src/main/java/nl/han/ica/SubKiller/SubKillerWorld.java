package nl.han.ica.SubKiller;

import java.io.FileNotFoundException;
import nl.han.ica.OOPDProcessingEngineHAN.Dashboard.Dashboard;
import nl.han.ica.OOPDProcessingEngineHAN.Engine.GameEngine;
import nl.han.ica.OOPDProcessingEngineHAN.Objects.GameObject;
import nl.han.ica.OOPDProcessingEngineHAN.View.View;
import processing.core.PApplet;

/**
 * Afgeleid van de HAN GameEngine. Verantwoordelijk voor de algehele besturing
 * van het spel. Bevat initialisatie, besturing van de verschillende
 * speltoestanden en spelovergangen. Toont voortgangsinformatie (dashboard) en
 * informatieve popups.
 */
public class SubKillerWorld extends GameEngine
		implements IGameObjectUpdateInteraction, IUpdateGameDashboard, IGameWorldInfo, IGameStateInteraction {

	private static final long serialVersionUID = -5008088640628960539L;
	private int playerHitpointsLeft;
	private BackGround background;
	private Text dashBoardText = new Text("");
	private LevelInfo levelInfo;
	private int currentLevel;
	private GameState currentGameState;
	private int score;
	private Player player;

	/**
	 *
	 * @param args
	 */
	public static void main(String[] args) {
		PApplet.main(new String[] { "nl.han.ica.SubKiller.SubKillerWorld" });
	}

	@Override
	public void setupGame() {
		try {
			createDashboard(SubKillerSettings.WorldWidth, 100);
			createViewWithoutViewport(SubKillerSettings.WorldWidth, SubKillerSettings.WorldHeight);

			createBackGround();

			initializeLevels();

			currentGameState = GameState.PRESTART;

		} catch (Exception e) {
			// Always a technical/programming error
			e.printStackTrace();
		}
	}

	private void initializeLevels() throws FileNotFoundException {
		levelInfo = new LevelInfo();
		levelInfo.LoadFromFile(SubKillerSettings.LevelInfoFileName);
	}

	private void createViewWithoutViewport(int screenWidth, int screenHeight) {
		View view = new View(screenWidth, screenHeight);
		setView(view);
		size(screenWidth, screenHeight);
	}

	private void createBackGround() {
		background = new BackGround(this);
		addGameObject(background, 0);
	}

	private void createDashboard(int dashboardWidth, int dashboardHeight) {
		Dashboard dashboard = new Dashboard(0, 0, dashboardWidth, dashboardHeight);
		dashboard.addGameObject(dashBoardText);
		addDashboard(dashboard);
	}

	@Override
	public void update() {
		try {
			switch (currentGameState) {
			case WAIT:
				break;
			case PRESTART:
				currentGameState = GameState.WAIT;
				showStartPopup();
				break;
			case START:
				startNewGame();
				break;
			case INPROGRESS:
				if (playerHitpointsLeft <= 0)
					processEndGameFailed();
				else if (checkIfLevelCompleted())
					processNextLevel();
				break;
			default:
				break;

			}
		} catch (Exception e) {
			// Always a technical/programming error
			e.printStackTrace();
		}
	}

	private void startNewGame() throws Exception {
		deleteAllGameOBjects();

		createBackGround();

		initializePlayer();

		currentLevel = 1;
		levelInfo.GetLevel(currentLevel).AddLevelObjectsToWorld(new AddLevelObjectsToWorldParameter(this, this, this));

		score = 0;
		playerHitpointsLeft = SubKillerSettings.PlayerHitpoints;

		UpdateDashBoard();
		currentGameState = GameState.INPROGRESS;
	}

	private void initializePlayer() {
		if (DepthChargeFactory.getFactoryInstance() == null)
			DepthChargeFactory.CreateFactory(this, this, this);
		AbstractWeaponFactory depthChargeFactory = DepthChargeFactory.getFactoryInstance();
		player = new Player(0, width, width / 2, getSeaSurfaceY(), Directions.LEFT, this, this, depthChargeFactory);
		addGameObjectToWorld(player);
	}

	private void showStartPopup() {
		StartPopup startPopup = new StartPopup(this, this);
		float popupX = (this.width - startPopup.getWidth()) / 2;
		float popupY = (this.height - startPopup.getHeight()) / 2;
		addGameObject(startPopup, popupX, popupY);
	}

	private void processNextLevel() throws Exception {
		if (currentLevel == levelInfo.getLevelCount())
			processEndGameCompleted();
		else
			prepareNextLevel();
	}

	private void prepareNextLevel() throws Exception {
		currentLevel++;
		levelInfo.GetLevel(currentLevel).AddLevelObjectsToWorld(new AddLevelObjectsToWorldParameter(this, this, this));
		player.resetHitPoints();
		UpdateDashBoard();
	}

	private void processEndGameCompleted() {
		currentGameState = GameState.WAIT;
		deleteResidualGameObjects();

		showEndSuccessPopup();
	}

	private void showEndSuccessPopup() {
		String text = String.format("Score %d. Press any key to start new game.", this.score);
		EndSuccessPopup endSuccessPopup = new EndSuccessPopup(text, this, this);
		float popupX = (this.width - endSuccessPopup.getWidth()) / 2;
		float popupY = (this.height - endSuccessPopup.getHeight()) / 2;
		endSuccessPopup.setTextSize(25);
		addGameObject(endSuccessPopup, popupX, popupY, 200);
	}

	private boolean checkIfLevelCompleted() {
		for (GameObject gameObject : this.getGameObjectItems()) {
			if (!(gameObject instanceof DestroyableGameObject)) {
				continue;
			}
			if (!((DestroyableGameObject) gameObject).isFriendly())
				return false;
		}
		return true;
	}

	private void processEndGameFailed() {
		currentGameState = GameState.WAIT;

		deleteResidualGameObjects();

		showEndGameFailedPopup();
	}

	private void showEndGameFailedPopup() {
		String text = String.format("You lost! At level %d with score %d. Press any key to restart game.",
				this.currentLevel, this.score);
		EndFailedPopup endFailedPopup = new EndFailedPopup(text, this, this);
		float popupX = (this.width - endFailedPopup.getWidth()) / 2;
		float popupY = (this.height - endFailedPopup.getHeight()) / 2;
		endFailedPopup.setTextSize(20);
		addGameObject(endFailedPopup, popupX, popupY);
	}

	private void deleteResidualGameObjects() {
		deleteAllGameObjectsOfType(SuperSubMarine.class);
		deleteAllGameObjectsOfType(SubMarine.class);
		deleteAllGameObjectsOfType(SeaMine.class);
		deleteAllGameObjectsOfType(Player.class);
		deleteAllGameObjectsOfType(Weapon.class);
	}

	@Override
	public void addGameObjectToWorld(GameObject gameObject) {
		addGameObject(gameObject, 250);
	}

	@Override
	public void removeGameObjectFromWorld(GameObject gameObject) {
		super.deleteGameObject(gameObject);
	}

	@Override
	public void updateScore(int scoreChange) {
		score += scoreChange;
		UpdateDashBoard();
	}

	private void UpdateDashBoard() {
		dashBoardText
				.setText(String.format("Level: %d  Health: %d  Score: %d", currentLevel, playerHitpointsLeft, score));
	}

	@Override
	public void updatePlayerHitpointsLeft(int hitpoints) {
		playerHitpointsLeft = hitpoints;
		UpdateDashBoard();
	}

	@Override
	public float getSeaSurfaceY() {
		return SubKillerSettings.AirHeight - 1;
	}

	@Override
	public float getSeaBottomY() {
		return getHeight() - SubKillerSettings.SeaBottomHeight - 1;
	}

	@Override
	public float getMaxX() {
		return getWidth() - 1;
	}

	@Override
	public float getMinY() {
		return 0;
	}

	@Override
	public float getMaxY() {
		return getHeight() - 1;
	}

	@Override
	public float getMinX() {
		return 0;
	}

	@Override
	public float getPlayerX() {
		if (player != null)
			return player.getX();
		else
			return -1;
	}

	@Override
	public float getPlayerY() {
		if (player != null)
			return player.getY();
		else
			return -1;
	}

	@Override
	public void setGameState(GameState gameState) {
		currentGameState = gameState;

	}
}
