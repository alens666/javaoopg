package nl.han.ica.SubKiller;

import nl.han.ica.OOPDProcessingEngineHAN.Objects.Sprite;

/**
 * Spelobject onderzeeër. Beweegt horizontaal heen-en-weer binnen het
 * speelveld. Vuurt zijn wapen af op een vast tijdsinterval.
 */
public class SubMarine extends AutonomousOperatingGameObject {

	/**
	 *
	 * @param minBoundary
	 * @param maxBoundary
	 * @param currentX
	 * @param currentY
	 * @param direction
	 * @param dashboardUpdater
	 * @param gameObjectsUpdater
	 * @param weaponFactory
	 */
	public SubMarine(float minBoundary, float maxBoundary, float currentX, float currentY, float direction,
			IUpdateGameDashboard dashboardUpdater, IGameObjectUpdateInteraction gameObjectsUpdater,
			IWeaponFactory weaponFactory) {
		super(new Sprite("src/main/java/nl/han/ica/SubKiller/media/SpriteSheetSubMarine.png"), 2,
				SubKillerSettings.SubMarineHitpoints, SubKillerSettings.SubMarineScore, minBoundary, maxBoundary,
				currentX, currentY, direction, SubKillerSettings.SubMarineSpeed, dashboardUpdater, gameObjectsUpdater,
				SubKillerSettings.EnemyObject, weaponFactory, SubKillerSettings.SubmarineWeaponYStartPoint,
				SubKillerSettings.SubmarineWeaponXStartPoint, SubKillerSettings.SubMarineAttackIntervalMilliSeconds);
	}

	@Override
	protected void AutoAttack() {
		if (attackCooldownPeriodInSecondsExpired())
			fireWeapon();
	}

	@Override
	protected void destroy() {
		super.destroy();
	}
}
