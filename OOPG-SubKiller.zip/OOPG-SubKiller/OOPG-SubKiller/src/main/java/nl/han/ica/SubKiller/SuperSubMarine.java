package nl.han.ica.SubKiller;

import nl.han.ica.OOPDProcessingEngineHAN.Objects.Sprite;

import java.util.Timer;
import java.util.TimerTask;

/**
 * Spelobject superonderzeer. Beweegt horizontaal heen-en-weer binnen het
 * speelveld. Vuurt zijn wapen af als hij zich op een bepaalde horizontale
 * afstand van de speler bevindt. Na afvuren wordt een periode gewacht voor er
 * weer gevuurd kan worden.
 */
public class SuperSubMarine extends AutonomousOperatingGameObject {
	private IGameWorldInfo gameWorldInfo;

	/**
	 *
	 * @param minBoundary
	 * @param maxBoundary
	 * @param currentX
	 * @param currentY
	 * @param direction
	 * @param dashboardUpdater
	 * @param gameObjectsUpdater
	 * @param weaponFactory
	 */
	public SuperSubMarine(float minBoundary, float maxBoundary, float currentX, float currentY, float direction,
			IUpdateGameDashboard dashboardUpdater, IGameObjectUpdateInteraction gameObjectsUpdater,
			IWeaponFactory weaponFactory, IGameWorldInfo iGameWorldInfo) {
		super(new Sprite("src/main/java/nl/han/ica/SubKiller/media/spriteSheetSuperSubMarine.png"), 2,
				SubKillerSettings.SuperSubMarineHitpoints, SubKillerSettings.SuperSubMarineScore, minBoundary,
				maxBoundary, currentX, currentY, direction, SubKillerSettings.SuperSubMarineSpeed, dashboardUpdater,
				gameObjectsUpdater, SubKillerSettings.EnemyObject, weaponFactory,
				SubKillerSettings.SuperSubmarineWeaponYStartPoint, SubKillerSettings.SuperSubmarineWeaponXStartPoint,
				SubKillerSettings.SuperSubMarineCoolDownMiliSeconds);
		this.gameWorldInfo = iGameWorldInfo;
	}

	@Override
	protected void AutoAttack() {
		float positionXplayer = gameWorldInfo.getPlayerX();
		float horizontalDistanceBetweenPlayerAndSuperSubmarine = Math.abs(positionXplayer - getX());
		float attackCapableDistance = SubKillerSettings.SuperSubMarineDistanceToAttack;

		if (horizontalDistanceBetweenPlayerAndSuperSubmarine < attackCapableDistance) {
			if (attackCooldownPeriodInSecondsExpired()) {
				fireWeapon();
			}
		}
	}

}
