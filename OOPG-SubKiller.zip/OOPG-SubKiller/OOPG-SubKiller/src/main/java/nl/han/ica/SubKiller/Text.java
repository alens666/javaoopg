package nl.han.ica.SubKiller;

import nl.han.ica.OOPDProcessingEngineHAN.Objects.GameObject;
import processing.core.PConstants;
import processing.core.PGraphics;

/**
 * Gameobject dat tekst toont
 */
public class Text extends GameObject {
	private String text;
	private int textSize = SubKillerSettings.DefaultPopupTextSize;

	/**
	 * @return int
	 */
	public int getTextSize() {
		return textSize;
	}

	/**
	 * @param textSize
	 */
	public void setTextSize(int textSize) {
		this.textSize = textSize;
	}

	/**
	 *
	 * @param text
	 */
	public Text(String text) {
		this.text = text;
	}

	/**
	 *
	 * @param text
	 */
	public void setText(String text) {
		this.text = text;
	}

	@Override
	public void update() {

	}

	@Override
	public void draw(PGraphics g) {
		g.fill(g.color(0, 0, 0));
		g.textAlign(PConstants.LEFT, PConstants.TOP);
		g.textSize(textSize);
		g.text(text, getX(), getY());
	}
}
