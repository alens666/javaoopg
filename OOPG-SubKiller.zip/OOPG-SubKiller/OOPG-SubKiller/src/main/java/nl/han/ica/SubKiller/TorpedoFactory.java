package nl.han.ica.SubKiller;

import nl.han.ica.OOPDProcessingEngineHAN.Objects.Sprite;

/**
 * Weaponfactories voor respectievelijk dieptebommen (gebruikt door het
 * marineschip), drijfbommen (gewone onderzeeër) en torpedo’s (super
 * onderzeeër).
 */
public class TorpedoFactory extends AbstractWeaponFactory {
	private static TorpedoFactory instance;

	/**
	 *
	 * @param gameObjectUpdater
	 * @param gameWorldInfo
	 * @param dashboardUpdater
	 */
	private TorpedoFactory(IGameObjectUpdateInteraction gameObjectUpdater, IGameWorldInfo gameWorldInfo,
			IUpdateGameDashboard dashboardUpdater) {
		super();
		this.setMinBoundary(gameWorldInfo.getSeaSurfaceY());
		this.setMaxBoundary(gameWorldInfo.getSeaBottomY());
		this.setDamageInflicted(SubKillerSettings.TorpedoDamage);
		this.setDashboardUpdater(dashboardUpdater);
		this.setDirection(Directions.UP);
		this.setFrames(1);
		this.setGameObjectUpdater(gameObjectUpdater);
		this.setGameObjectsUpdater(gameObjectUpdater);
		this.setHitpoints(SubKillerSettings.TorpedoHitpoints);
		this.setScoreWhenDestroyed(SubKillerSettings.TorpedoScore);
		this.setSpeed(SubKillerSettings.TorpedoSpeed);
		this.setSprite(new Sprite("src/main/java/nl/han/ica/SubKiller/media/torpedo.png"));
	}

	@Override
	public void CreateWeapon(float x, float y) {
		Weapon weapon = new Weapon(getSprite(), getFrames(), getHitpoints(), getScoreWhenDestroyed(), getMinBoundary(),
				getMaxBoundary(), x, y, getDirection(), getSpeed(), getDashboardUpdater(), getGameObjectsUpdater(),
				getDamageInflicted(), SubKillerSettings.EnemyObject);
		getGameObjectUpdater().addGameObjectToWorld(weapon);
	}

	/**
	 * Create an instance of TorpedoFactory
	 * 
	 * @param gameObjectUpdater
	 * @param gameWorldInfo
	 * @param dashboardUpdater
	 */
	public static void CreateFactory(IGameObjectUpdateInteraction gameObjectUpdater, IGameWorldInfo gameWorldInfo,
			IUpdateGameDashboard dashboardUpdater) {
		instance = new TorpedoFactory(gameObjectUpdater, gameWorldInfo, dashboardUpdater);
	}

	/**
	 * Get an instance of TorpedoFactory
	 * 
	 * @return TorpedoFactory
	 */
	public static TorpedoFactory getFactoryInstance() {
		return instance;
	}
}
