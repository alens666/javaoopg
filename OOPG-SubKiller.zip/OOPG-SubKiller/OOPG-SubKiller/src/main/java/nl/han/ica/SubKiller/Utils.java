package nl.han.ica.SubKiller;

/**
 * Klasse die nuttige algemene functies huisvest.
 */
public class Utils {
	private Utils() {
		super();
	}

	/**
	 *
	 * @param arrayToTrim
	 */
	public static void TrimStringArrayLines(String[] arrayToTrim) {
		for (int i = 0; i < arrayToTrim.length; i++)
			arrayToTrim[i] = arrayToTrim[i].trim();
	}
}
