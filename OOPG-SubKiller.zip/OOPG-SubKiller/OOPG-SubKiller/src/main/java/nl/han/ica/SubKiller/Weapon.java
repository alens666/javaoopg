package nl.han.ica.SubKiller;

import nl.han.ica.OOPDProcessingEngineHAN.Objects.Sprite;

/**
 * Spelobject dat enig wapen kan representeren. Bevat informatie over de
 * afbeelding/plaatje, en de schade die het wapen doet. Wordt gemaakt door een
 * WeaponFactory.
 */
public class Weapon extends DestroyableGameObject {
	private int damageInflicted;

	/**
	 *
	 * @param sprite
	 * @param frames
	 * @param hitpoints
	 * @param scoreWhenDestroyed
	 * @param minBoundary
	 * @param maxBoundary
	 * @param currentX
	 * @param currentY
	 * @param direction
	 * @param speed
	 * @param dashboardUpdater
	 * @param gameObjectsUpdater
	 * @param damageInflicted
	 * @param isFriendly
	 */
	public Weapon(Sprite sprite, int frames, int hitpoints, int scoreWhenDestroyed, float minBoundary,
			float maxBoundary, float currentX, float currentY, float direction, float speed,
			IUpdateGameDashboard dashboardUpdater, IGameObjectUpdateInteraction gameObjectsUpdater, int damageInflicted,
			boolean isFriendly) {
		super(sprite, frames, hitpoints, scoreWhenDestroyed, minBoundary, maxBoundary, currentX, currentY, direction,
				speed, dashboardUpdater, gameObjectsUpdater, isFriendly);
		this.damageInflicted = damageInflicted;
	}

	/**
	 *
	 * @return int
	 */
	protected int getDamageInflicted() {
		return damageInflicted;
	}

	@Override
	public void update() {
		// Weapons disappear when exceeding boundaries without hititng anything
		if (getY() <= getMinBoundary() || getY() >= getMaxBoundary()) {
			getGameObjectsUpdater().removeGameObjectFromWorld(this);
		}
	}

}
